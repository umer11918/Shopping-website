<?php 
/* 
| Developed by: Tauseef Ahmad
| Last Upate: 27-08-2020 03:45 PM
| Facebook: www.facebook.com/ahmadlogs
| Twitter: www.twitter.com/ahmadlogs
| YouTube: https://www.youtube.com/channel/UCOXYfOHgu-C-UfGyDcu5sYw/
| Blog: https://ahmadlogs.wordpress.com/
 */ 
 
 
/* 
|  
| JAZZCASH configuration 
| 
 */

define('JAZZCASH_MERCHANT_ID', 'enter_merchant_id');
define('JAZZCASH_PASSWORD', 'enter_password');
define('JAZZCASH_INTEGERITY_SALT', 'enter_integerity_salt');
define('JAZZCASH_RETURN_URL', 'enter_return_url');

define('JAZZCASH_CURRENCY_CODE', 'PKR');
define('JAZZCASH_LANGUAGE', 'EN');
define('JAZZCASH_API_VERSION_1', '1.1');
//define('JAZZCASH_API_VERSION_2', '2.0');

define('JAZZCASH_HTTP_POST_URL', 'https://sandbox.jazzcash.com.pk/CustomerPortal/transactionmanagement/merchantform/');
 

/* 
| 
| Database configuration 
|
 */ 
 
define('DB_HOST', 'enter_database_host'); 
define('DB_USERNAME', 'enter_database_username'); 
define('DB_PASSWORD', 'enter_database_password'); 
define('DB_NAME', 'enter_database_name');


define('BASE_URL', 'enter_website_url');


define('PART', '6');